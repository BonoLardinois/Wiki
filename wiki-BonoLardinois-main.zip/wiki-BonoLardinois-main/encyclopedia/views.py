from django.shortcuts import render
from django import forms
import random
from . import util
import markdown2

class Search(forms.Form):
    search_term = forms.CharField(label="Search")
    
class Create_title(forms.Form):
    new_title = forms.CharField(label="Title:")

class Create_text(forms.Form):
    new_text = forms.CharField(widget=forms.Textarea, label="")

class Edit_text(forms.Form):
    edit_text = forms.CharField(widget=forms.Textarea, label="")


def index(request):
    titles = util.list_entries()
    search_titles= set()  

    # if search field is being used    
    if request.method=="POST":
        form = Search(request.POST)
        if form.is_valid():
            search_term = form.cleaned_data["search_term"]
            for title in titles:

                # if search term is same as a title, return specific entry page
                if search_term.lower() == title.lower():
                    package = {
                        "title": title.capitalize(), 
                        "text": markdown2.markdown(util.get_entry(title)), 
                        "form": Search()
                    }
                    return render(request, "encyclopedia/entry.html", package)
                        
                # input not same than a list of options is provided
                else: 
                    if search_term.lower() in title.lower():
                        search_titles.add(title)

            package = {
                "list_titles": search_titles,
                "form": Search()
                }
            return render(request, "encyclopedia/search.html", package)

    # else return index page
    package = {
        "entries": util.list_entries(), 
        "form": Search()
    }
    return render(request, "encyclopedia/index.html", package)

def entry(request, title):
    # if title in list with titles then return that specific page
    if title in util.list_entries():
        package = {
        "title": title.capitalize(), 
        "text": markdown2.markdown(util.get_entry(title)), 
        "form": Search()
        }
        return render(request, "encyclopedia/entry.html", package)

    # else retrun error page
    return render(request, "encyclopedia/error.html", {
        "title": title, "form":Search()
    })

def create(request):
    if request.method=="POST":
        if request.POST.get('title') and request.POST.get('text_area'):
            title_new = request.POST.get('title')

            # if the title already exists, return error page
            for entry in util.list_entries():
                if title_new.lower() == entry.lower():
                    return render(request, "encyclopedia/create_error.html",{
                    "title": title_new.capitalize()
                    })

            # if page doesn't exist, then save the new page and return it
            text_new = request.POST.get('text_area')
            util.save_entry(title_new.capitalize(),text_new)
            package = {
                    "entries": util.list_entries(), 
                    "form": Search()
                }
            return render(request, "encyclopedia/index.html", package)

    # else return de create page        
    return render(request, "encyclopedia/create.html",{
        "form_title": Create_title(), "form_text": Create_text, "form": Search()
        })

def edit(request, title):
    if request.method=="POST":
        
        # when user wants to edit page
        if request.POST.get('edit'):
            text = request.POST.get('edit')
            util.save_entry(title, text)

            # return the edited page
            package = {
                "title": title.capitalize(), 
                "text": markdown2.markdown(text), 
                "form": Search()
            }
            return render(request, "encyclopedia/entry.html", package)

    # returns the edit page with text of page pre-loaded in textfield        
    package = {
        "title": title,
        "text": markdown2.markdown(util.get_entry(title)),
        "text_edit": Edit_text(), 
        "form": Search()
        }
    return render(request, "encyclopedia/edit.html", package)

def random_(request): 
    # selects a random title from the list and returns that specific page  
    random_title = random.choice(util.list_entries())
    package = {
        "title": random_title.capitalize(), 
        "text": util.get_entry(random_title), 
        "form": Search()
        }
    return render(request, "encyclopedia/entry.html", package)



    
