<h1>Python</h1>

<p>Python is a programming language that can be used both for writing <strong>command-line scripts</strong> or building <strong>web applications</strong>.</p>
