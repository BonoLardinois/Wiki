# Application Name
wikipedia page with search, create, random and edit function


## Getting Started

1. download with: git clone https://github.com/uva-webapps/wiki-BonoLardinois.git
2. open in text editor
3. run the site with python manage.py runserver
4. the site opens in the prefered browser


Search: this application will search throught the list of titles and return a page which matches the input. If the input doesn't match any title it will return an error. If the input has more then one match it will display them all in a list.

create: the create page lets the user create a new page where he or she can make a complet new wiki page with a title and some markdown language. 

random: the random button will select a random title from the list of titles and display the entry page of the random title to the user

edit: the edit button will link to a page where all the titles are listed. When one title is selected the user will be linked to this page and will be able to edit a certain page. 

Prototypes of the page:

![Index page@1x](https://user-images.githubusercontent.com/78788799/115261569-03429a80-a134-11eb-9638-9ca96a222c6f.jpg)

![entry page@1x](https://user-images.githubusercontent.com/78788799/115261567-02aa0400-a134-11eb-9ec1-feeedfa794d9.jpg)

![Search@1x](https://user-images.githubusercontent.com/78788799/115261573-03429a80-a134-11eb-9c50-f622147f4054.jpg)

![Create new page@1x](https://user-images.githubusercontent.com/78788799/115261557-00e04080-a134-11eb-8e1c-e4896a7f3195.jpg)

![Edit page@1x](https://user-images.githubusercontent.com/78788799/115261563-0178d700-a134-11eb-9056-f2653b673876.jpg)



